/**
 * @file    hal_dsp_iso14443a_pcd.h
 * @brief   ISO14443A Proximity Coupling Device (card reader) device-specific MFRC522 driver
 *
 * @addtogroup ISO14443A_PCD
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if (HAL_USE_ISO14443A_PCD == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

typedef enum {
    PCD_UNCONFIGURED = 0,            /**< The driver has not been configured */
    PCD_STOPPED      = 0,            /**< The driver is not yet initialized  */
    PCD_ANTENNA_OFF  = 1,            /**< Device has the antenna turned off  */
    PCD_READY        = 2,            /**< The device is ready                */
    PCD_BUSY         = 3             /**< The device is doing something      */
} PCDDriverState;

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/


/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief Enumaration of possible MFRC522 speeds
 */
typedef enum {
    PCD_SPEED_ANTICOLL = 0,         /**< 106kBd, for anticollision loop      */
    PCD_SPEED_212      = 1,         /**< 212kBd                              */
    PCD_SPEED_424      = 2,         /**< 424kBd                              */
    PCD_SPEED_848      = 3,         /**< 848kBd                              */
} PCDSpeed;

/**
 * @brief Possible Rx/Tx configuration of the MFRC522 module
 */
struct PCDCommunicationParameters {
    PCDSpeed tx_speed;              /**< Transmit speed of the module        */
    PCDSpeed rx_speed;              /**< Receive speed of the module         */
    bool tx_crc_en;                 /**< Automatically compute CRC for tx    */
    bool rx_crc_en;                 /**< Automatically verify CRC for rx data*/
    bool ask100mod;                 /**< Force 100% ASK modulation           */
    uint8_t min_signal_level;       /**< Minimal interpreted signal level    */
    uint8_t collision_level;        /**< Signal collision detection level    */
    uint8_t miller_modulation_width;/**< Width of Miller modulation          */
    uint8_t receiver_gain;          /**< Gain of the receiver circuit        */
};

// TODO SPI SPECIFIC!
/**
 * @brief MFRC522 Driver configuration
 */
struct PCDConfig {
    SPIDriver *spip;                /**< Which SPI driver to use             */
    SPIConfig *spic;                /**< SPI driver configuration to use     */
};

struct PCDDriver {
    SPIDriver *spip;                /**< Which SPI driver to use             */
    PCDDriverState state;           /**< State of the driver                 */
    void (*gpio_set_reset)(bool);  /**< Function for setting the reset pin  */
};

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

    void ISO14443A_PCD_dsp_init(void);
    void ISO14443A_PCD_driver_object_init(PCDDriver *pcdp);
    void ISO14443A_PCD_dsp_start(PCDDriver *pcdp, PCDConfig *config);
    void ISO14443A_PCD_dsp_stop(PCDDriver *pcdp);

    PCDStatus ISO14443A_PCD_dsp_antenna_on(PCDDriver *pcdp);
    PCDStatus ISO14443A_PCD_dsp_antenna_off(PCDDriver *pcdp);
    uint16_t ISO14443A_PCD_calculate_crc(PCDDriver *pcdp, uint8_t *buffer, uint8_t length);
    PCDStatus ISO14443A_PCD_dsp_perform_self_test(PCDDriver *pcdp);
    PCDStatus ISO14443A_PCD_dsp_set_comm_params(PCDDriver *pcdp, PCDCommunicationParameters *params);
    PCDStatus ISO14443A_PCD_dsp_sync_transmit(PCDDriver* pcdp, uint8_t* buffer, uint8_t length,
                                              uint8_t last_bits);
    PCDStatus ISO14443A_PCD_dsp_sync_receive(PCDDriver* pcdp, uint8_t* buffer, uint8_t *length,
                                             uint8_t bits_align);
    PCDStatus ISO14443A_PCD_dsp_sync_transceive(PCDDriver* pcdp, uint8_t *tx_buffer, uint8_t *rx_buffer, uint8_t *length,
                                                uint8_t last_bits, uint8_t bits_align);
    uint8_t ISO14443A_PCD_dsp_get_coll_position(PCDDriver* pcdp);
    PCDStatus ISO14443A_PCD_dsp_sync_mfauthent(PCDDriver* pcdp, uint8_t command_code,
                                               uint8_t block_address, uint8_t* sector_key,
                                               uint8_t* serial_number);

#ifdef __cplusplus
}
#endif

#endif /* HAL_USE_ISO14443A_PCD */

/** @} */

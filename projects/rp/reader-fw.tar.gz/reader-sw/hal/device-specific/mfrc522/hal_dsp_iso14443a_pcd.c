/**
 * @file    mfrc522/hal_dsp_iso14443a_pcd.c
 * @brief   ISO14443A PCD driver implementation for the MFRC522 module
 *
 * @addtogroup ISO14443A_PCD
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if HAL_USE_ISO14443A_PCD || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

typedef enum {
    PCD_IDLE            = 0x00,
    PCD_AUTHENT         = 0x0E,
    PCD_RECEIVE         = 0x08,
    PCD_TRANSMIT        = 0x04,
    PCD_TRANSCEIVE      = 0x0C,
    PCD_RESETPHASE      = 0x0F,
    PCD_CALCCRC         = 0x03
} Mfrc522Command;

typedef enum {
    Reserved00          = 0x00,
    CommandReg          = 0x01,
    ComIEnReg           = 0x02,
    DivlEnReg           = 0x03,
    CommIrqReg          = 0x04,
    DivIrqReg           = 0x05,
    ErrorReg            = 0x06,
    Status1Reg          = 0x07,
    Status2Reg          = 0x08,
    FIFODataReg         = 0x09,
    FIFOLevelReg        = 0x0A,
    WaterLevelReg       = 0x0B,
    ControlReg          = 0x0C,
    BitFramingReg       = 0x0D,
    CollReg             = 0x0E,
    Reserved01          = 0x0F,
    Reserved10          = 0x10,
    ModeReg             = 0x11,
    TxModeReg           = 0x12,
    RxModeReg           = 0x13,
    TxControlReg        = 0x14,
    TxASKReg            = 0x15,
    TxSelReg            = 0x16,
    RxSelReg            = 0x17,
    RxThresholdReg      = 0x18,
    DemodReg            = 0x19,
    Reserved11          = 0x1A,
    Reserved12          = 0x1B,
    MfTxReg             = 0x1C,
    MfRxReg             = 0x1D,
    Reserved14          = 0x1E,
    SerialSpeedReg      = 0x1F,
    Reserved20          = 0x20,
    CRCResultRegL       = 0x21,
    CRCResultRegH       = 0x22,
    Reserved21          = 0x23,
    ModWidthReg         = 0x24,
    Reserved22          = 0x25,
    RFCfgReg            = 0x26,
    GsNReg              = 0x27,
    CWGsPReg            = 0x28,
    ModGsPReg           = 0x29,
    TModeReg            = 0x2A,
    TPrescalerReg       = 0x2B,
    TReloadRegH         = 0x2C,
    TReloadRegL         = 0x2D,
    TCounterValueRegH   = 0x2E,
    TCounterValueRegL   = 0x2F,
    Reserved30          = 0x30,
    TestSel1Reg         = 0x31,
    TestSel2Reg         = 0x32,
    TestPinEnReg        = 0x33,
    TestPinValueReg     = 0x34,
    TestBusReg          = 0x35,
    AutoTestReg         = 0x36,
    VersionReg          = 0x37,
    AnalogTestReg       = 0x38,
    TestDAC1Reg         = 0x39,
    TestDAC2Reg         = 0x3A,
    TestADCReg          = 0x3B,
    Reserved31          = 0x3C,
    Reserved32          = 0x3D,
    Reserved33          = 0x3E,
    Reserved34          = 0x3F
} MFRC522Register;

#define ADDRESS_MASK 0b01111110
#define ADDRESS_READ 0b10000000

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

void mfrc522_write_register(PCDDriver *pcdp, MFRC522Register address, uint8_t value) {
    uint8_t const tx[] = {(address << 1) & ADDRESS_MASK, value};
    spiSelect(pcdp->spip);
    spiSend(pcdp->spip, sizeof(tx), tx);
    spiUnselect(pcdp->spip);
}

uint8_t mfrc522_read_register(PCDDriver *pcdp, MFRC522Register address) {
    uint8_t const tx[] = {((address << 1) & ADDRESS_MASK) | ADDRESS_READ, 0x00};
    uint8_t rx[2];
    spiSelect(pcdp->spip);
    spiExchange(pcdp->spip, sizeof(tx), tx, rx);
    spiUnselect(pcdp->spip);
    return rx[1];
}

#define mfrc522_set_mask(pcdp, address, mask)   (mfrc522_write_register((pcdp), (address), mfrc522_read_register((pcdp), (address)) | (mask)))
#define mfrc522_clear_mask(pcdp, address, mask) (mfrc522_write_register((pcdp), (address), mfrc522_read_register((pcdp), (address)) & ~(mask)))

#define mfrc522_power_up(pcdp)   ((pcdp)->gpio_set_reset(true))
#define mfrc522_power_down(pcdp) ((pcdp)->gpio_set_reset(false))

#define mfrc522_reset(pcdp) {mfrc522_power_down(pcdp); mfrc522_power_up(pcdp);}

#define mfrc522_command(pcdp, command) (mfrc522_write_register(pcdp, CommandReg, command))

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Device-specific ISO14443A PCD driver initialization
 *
 * @notapi
 */
void ISO14443A_PCD_dsp_init(void) {
    // There is nothing to do for this MFRC522 driver
}

/**
 * @brief   Device-specific object init
 *
 * @notapi
 */
void ISO14443A_PCD_dsp_object_init(PCDDriver *pcdp) {
    // The driver is uninitialized
    pcdp->state = PCD_UNCONFIGURED;
}

/**
 * @brief   Configures and activates the ISO14443A Proximity Coupling Device
 *
 * @notapi
 */
void ISO14443A_PCD_dsp_start(PCDDriver *pcdp, PCDConfig *config) {
    pcdp->spip = config->spip;
    pcdp->state = PCD_STOPPED;
    spiStart(pcdp->spip, config->spic);

    mfrc522_reset(pcdp);
    chThdSleepMicroseconds(40); // Oscillator start-up time


    // TODO clean up and don't use magic constants
    // Set TAuto - timer starts automatically after the enf of transmission
    //     TPrescaler_Hi - set to 0x0D
    mfrc522_write_register(pcdp, TModeReg, 0x8D);

    // Set TPrescaler_Lo - set to 0x3E.
    // Together with TPrescaler_Hi the timer will run at approx 2KHz
    mfrc522_write_register(pcdp, TPrescalerReg, 0x3E);

    // Set reload value to 0x1E. The timer will run for approx 15ms.
    mfrc522_write_register(pcdp, TReloadRegH, 0x00);
    mfrc522_write_register(pcdp, TReloadRegL, 0x1E);

    // Set TXWaitRF   : Transmitter will only start if the RF field is
    //                  is present
    //     PolMFin    : MFIN pin is active HIGH
    //     CRCPreset  : to 0x6363 as specified in ISO/IEC 14443
    mfrc522_write_register(pcdp, ModeReg, 0x3D);

    pcdp->state = PCD_READY;
}

/**
 * @brief   Deactivates the ISO14443A Proximity Coupling Device
 *
 * @notapi
 */
void ISO14443A_PCD_dsp_stop(PCDDriver *pcdp) {
    pcdp->state = PCD_STOPPED;
    mfrc522_power_down(pcdp);
    spiStop(pcdp->spip);
}

/**
 * @brief   Turns on the antenna of MFRC522
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_antenna_on(PCDDriver *pcdp) {
    mfrc522_set_mask(pcdp, TxControlReg, 0x03);
    return PCD_STATUS_OK;
}

/**
 * @brief   Turns off the antenna of MFRC522
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_antenna_off(PCDDriver *pcdp) {
    mfrc522_clear_mask(pcdp, TxControlReg, 0x03);
    return PCD_STATUS_OK;
}

/**
 * @brief   Calculates CRC
 *
 * @notapi
 */
uint16_t ISO14443A_PCD_calculate_crc(PCDDriver *pcdp, uint8_t *buffer, uint8_t length) {
    mfrc522_command(pcdp, PCD_IDLE);

    // Flush the FIFO
    mfrc522_set_mask(pcdp, FIFOLevelReg, 0x80);

    for (int i = 0; i < length; i++) {
        mfrc522_write_register(pcdp, FIFODataReg, *(buffer++));
    }

    mfrc522_command(pcdp, PCD_CALCCRC);

    while(! (mfrc522_read_register(pcdp, DivIrqReg) & 0x04)) {
        ;
    }

    return (mfrc522_read_register(pcdp, CRCResultRegH)) | (mfrc522_read_register(pcdp, CRCResultRegL) << 8);
}

/**
 * @brief   Preforms the self-test on the MFRC522
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_perform_self_test(PCDDriver *pcdp) {
    (void)pcdp;
    return PCD_NOT_IMPLEMENTED;
}

/**
 * @brief   Configures the communication parameters of the Proximity Coupling Device
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_set_comm_params(PCDDriver *pcdp, PCDCommunicationParameters *params) {
    (void)pcdp;
    (void)params;
    return PCD_NOT_IMPLEMENTED;
}

/**
 * @brief   Transmits data to the card. Blocks while the transmission is in progress
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_sync_transmit(PCDDriver *pcdp, uint8_t* buffer, uint8_t length,
                                          uint8_t last_bits) {
    (void)pcdp;
    (void)buffer;
    (void)length;
    (void)last_bits;
    return PCD_NOT_IMPLEMENTED;
}

/**
 * @brief   Receive data from the card. Blocks while the reception is in progress
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_sync_receive(PCDDriver *pcdp, uint8_t* buffer, uint8_t *length,
                                         uint8_t bits_align) {
    (void)pcdp;
    (void)buffer;
    (void)length;
    (void)bits_align;
    return PCD_NOT_IMPLEMENTED;
}

/**
 * @brief   Sends and receives data. Blocks while the operation is in progress
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_sync_transceive(PCDDriver *pcdp, uint8_t *tx_buffer, uint8_t *rx_buffer, uint8_t *length,
                                            uint8_t last_bits, uint8_t bits_align) {
    (void)last_bits;
    (void)bits_align;
    // Invert output interrupt signal; enable Tx interrupt, Rx interrupt,
    // idle interrupt, FIFO Low interrupt, ErrorInterrupt and TimerInterrupt.
    mfrc522_write_register(pcdp, ComIEnReg, 0xF7);
    // Clear interrupt request bits
    mfrc522_clear_mask(pcdp, CommIrqReg, 0x80);
    // Flush the FIFO
    mfrc522_write_register(pcdp, FIFOLevelReg, 0x80);

    for (uint16_t i = 0; i < *length; i++) {
        mfrc522_write_register(pcdp, FIFODataReg, *(tx_buffer++));
    }

    mfrc522_command(pcdp, PCD_TRANSCEIVE);

    uint8_t bit_framing_reg = mfrc522_read_register(pcdp, BitFramingReg);
    // Set 'StartSend' bit
    mfrc522_write_register(pcdp, BitFramingReg, (bits_align & 0x07) | ((last_bits & 0x07) << 4) | 0x80);

    // Busy wait for the transmission to finish, error or timeout
    uint8_t irq_reg;
    while (true) {
        irq_reg = mfrc522_read_register(pcdp, CommIrqReg);
        // Check interrupts: Tx and Rx complete, error or timeout
        if (((irq_reg & 0x20) && (irq_reg & 0x40)) || (irq_reg & 0x03)) {
            break;
        }
    }

    // Restore original BitFraming register
    mfrc522_write_register(pcdp, BitFramingReg, bit_framing_reg);

    // TODO this may not handle all the cases
    if (irq_reg & 0x02) {
        uint8_t error = mfrc522_read_register(pcdp, ErrorReg);
        if (error & 0x1B) {
            mfrc522_command(pcdp, PCD_IDLE);
            return PCD_COMM_ERROR;
        }
    }

    // Timeout
    if (irq_reg & 0x01) {
        mfrc522_command(pcdp, PCD_IDLE);
        return PCD_NO_PICC;
    }

    uint8_t response_length = mfrc522_read_register(pcdp, FIFOLevelReg);

    *length = response_length;

    for (uint8_t i = 0; i < response_length; i++) {
        *(rx_buffer++) = mfrc522_read_register(pcdp, FIFODataReg);
    }

    mfrc522_command(pcdp, PCD_IDLE);

    return PCD_STATUS_OK;
}

/**
 * @brief   In case of a bit-collision during reception reports the collision position
 *
 * @notapi
 */
uint8_t ISO14443A_PCD_dsp_get_coll_position(PCDDriver* pcdp) {
    (void)pcdp;
    return PCD_NOT_IMPLEMENTED;
}

/**
 * @brief   Performs an Mifare authentication with the card
 *
 * @notapi
 */
PCDStatus ISO14443A_PCD_dsp_sync_mfauthent(PCDDriver* pcdp, uint8_t command_code,
                                           uint8_t block_address, uint8_t* sector_key,
                                           uint8_t* serial_number) {
    (void)pcdp;
    (void)command_code;
    (void)block_address;
    (void)sector_key;
    (void)serial_number;
    return PCD_NOT_IMPLEMENTED;
}


#endif /* HAL_USE_ISO14443A_PCD */

/** @} */

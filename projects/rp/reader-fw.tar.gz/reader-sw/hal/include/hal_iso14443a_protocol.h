/**
 * @file    hal_iso14443a_protocol.h
 * @brief   ISO14443A Protocol (part 3 and 4) implementation
 *
 * @addtogroup ISO14443A_PROTOCOL
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if (HAL_USE_ISO14443A_PROTOCOL == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/


/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

// TODO

typedef enum {
    ISO14443A_STOPPED      = 0,
    ISO14443A_READY        = 1
} ISO14443AStatus;

/**
 * @brief   Structure representing an UID of a PICC
 */
typedef struct {
    uint8_t size;
    uint8_t bytes[10];
} PICC_UID;

/**
 * @brief   Structure representing a ISO14443A Protocol driver
 */
typedef struct {
    ISO14443AStatus status;
    PCDDriver *pcdp;
} ISO14443AProtocol;

typedef struct {
    PCDConfig *pcd_config;
    PCDDriver *pcd_driver;
} ISO14443AProtocolConfig;

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/


#ifdef __cplusplus
extern "C" {
#endif

    void iso14443aInit(void);
    void iso14443aObjectInit(ISO14443AProtocol *pp);
    void iso14443aStart(ISO14443AProtocol *pp, ISO14443AProtocolConfig *config);

    bool iso14443aRequest(ISO14443AProtocol *pp, uint8_t req_mode, uint8_t tag_type);
    void iso14443aAnticollision(ISO14443AProtocol *pp, uint8_t max_uids, PICC_UID *detected_uids,
                                uint8_t* uids_amount);
    bool iso14443aPICCSelect(ISO14443AProtocol *pp, uint8_t command, PICC_UID *uid);
    bool iso14443aPICCAuthenticate(ISO14443AProtocol *pp, uint8_t command_code,
                                   uint8_t block_address, uint8_t *sector_key,
                                   uint8_t *serial_number);
    bool iso14443aPICCRead(ISO14443AProtocol *pp, uint8_t block_address, uint8_t *buffer);
    bool iso14443aPICCWrite(ISO14443AProtocol *pp, uint8_t block_address, uint8_t *buffer);
    bool iso14443aPICCHalt(ISO14443AProtocol *pp);


#ifdef __cplusplus
}
#endif


#endif /* HAL_USE_ISO14443A_PROTOCOL */

/** @} */

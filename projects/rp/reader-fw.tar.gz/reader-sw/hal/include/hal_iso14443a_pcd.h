/**
 * @file    hal_iso14443a_pcd.h
 * @brief   ISO14443A Proximity Coupling Device (card reader) abstract driver code.
 *
 * @addtogroup ISO14443A_PCD
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if (HAL_USE_ISO14443A_PCD == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

typedef enum {
    PCD_STATUS_OK            = 0,    /**< Operation successful               */
    PCD_NOT_IMPLEMENTED      = 1,    /**< Function not implemented           */
    PCD_TEST_ERROR           = 2,    /**< Self-test error                    */
    PCD_BIT_COLLISION        = 3,    /**< Success, bit-collision detected    */
    PCD_COMM_ERROR           = 4,    /**< Error when communicating with PICC */
    PCD_NO_PICC              = 5     /**< No card detected                   */
} PCDStatus;

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/


/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

// Include device-specific driver

// Good tautology is never bad

/**
 * @brief   Structure representing a ISO14443a PCD driver
 */
typedef struct PCDDriver PCDDriver;

/**
 * @brief   Structure representing communication parameters of a given PCD
 */
typedef struct PCDCommunicationParameters PCDCommunicationParameters;

/**
 * @brief   Structure representing configuration of a given PCD
 */
typedef struct PCDConfig PCDConfig;

#include "hal_dsp_iso14443a_pcd.h"

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

    void pcdInit(void);
    void pcdObjectInit(PCDDriver* pcdp);
    void pcdStart(PCDDriver* pcdp, PCDConfig* config);
    void pcdStop(PCDDriver* pcdp);

    PCDStatus pcdAntennaOn(PCDDriver *pcdp);
    PCDStatus pcdAntennaOff(PCDDriver *pcdp);
    uint16_t pcdCalculateCRC(PCDDriver *pcdp, uint8_t *buffer, uint8_t length);
    PCDStatus pcdPerformSelfTest(PCDDriver *pcdp);
    PCDStatus pcdSetCommunicationParameters(PCDDriver* pcdp, PCDCommunicationParameters *params);
    PCDStatus pcdSynchronousTransmit(PCDDriver *pcdp, uint8_t* buffer, uint8_t length,
                                     uint8_t last_bits);
    PCDStatus pcdSynchronousReceive(PCDDriver *pcdp, uint8_t *buffer, uint8_t *length,
                                    uint8_t bits_align);
    // TODO these param names are confusing!
    // TODO TX length and RX length should be separate!
    PCDStatus pcdSynchronousTransceive(PCDDriver *pcdp, uint8_t *buffer_tx, uint8_t *buffer_rx, uint8_t *length,
                                       uint8_t last_bits, uint8_t bits_align);
    uint8_t pcdGetReceiveCollisionPosition(PCDDriver *pcdp);
    PCDStatus pcdSynchronousMifareAutheht(PCDDriver *pcdp, uint8_t command_code,
                                          uint8_t block_address, uint8_t *sector_key,
                                          uint8_t *serial_number);

#ifdef __cplusplus
}
#endif


#endif /* HAL_USE_ISO14443A_PCD */

/** @} */

/**
 * @file    hal_iso14443a_protocol.c
 * @brief   ISO14443A Protocol (part 3 and 4) implementation
 *
 * @addtogroup ISO14443A_PROTOCOL
 * @{
 */

#include <string.h>
#include "hal.h"
#include "hal_custom.h"

#if HAL_USE_ISO14443A_PROTOCOL || defined(__DOXYGEN__)

// TODO this is just a port of the old implementation to a new framework.
// Needs polishing.

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

typedef enum {
    REQA        = 0x26,
    ANTICOLL_1  = 0x93,
    ANTICOLL_2  = 0x95,
    ANTICOLL_3  = 0x97,
} CardCommand;

#define CARD_ERROR -1
#define CARD_NOT_PRESENT -2

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

static int8_t iso14443_perform_cascade(ISO14443AProtocol *pp, uint8_t *id) {
    uint8_t buffer[64];
    PCDStatus status;
    int8_t id_size = 0;

    for (int i = 0; i < 3; i++) {
        uint8_t cascade_level;
        switch (i) {
            case 0:
                cascade_level = ANTICOLL_1;
                break;
            case 1:
                cascade_level = ANTICOLL_2;
                break;
            case 2:
                cascade_level = ANTICOLL_3;
                break;
            default:
                cascade_level = ANTICOLL_1;
                break;
        }

        buffer[0] = cascade_level;
        buffer[1] = 0x20;

        // Transmit ANTICOLLISION
        uint8_t trx_length = 2;
        status = pcdSynchronousTransceive(pp->pcdp, buffer, (buffer+2), &trx_length, 0, 0);

        uint8_t uid_cln[5];

        if (status == PCD_NO_PICC) return CARD_NOT_PRESENT;
        if (status == PCD_COMM_ERROR || trx_length != 5) return CARD_ERROR;

        memcpy(uid_cln, (buffer+2), 5);

        // Transmit SELECT
        buffer[1] = 0x70;
        uint16_t crc = pcdCalculateCRC(pp->pcdp, buffer, trx_length+2);
        buffer[2+trx_length] = (uint8_t)(crc & 0xFF);
        buffer[2+trx_length+1] = (uint8_t)((crc & 0xFF00) >> 8);

        trx_length += 4;
        status = pcdSynchronousTransceive(pp->pcdp, buffer, buffer, &trx_length, 0, 0);

        if (status == PCD_NO_PICC) return CARD_NOT_PRESENT;
        if (status == PCD_COMM_ERROR) return CARD_ERROR;

        if ((buffer[0] & 0x24) == 0x00) {
            // UID complete, PICC is NOT compliant with ISO/IEC 14443-4, but we don't care at this point
            memcpy(uid_cln, id, 4);
            id_size += 4;
            return id_size;
        } else if ((buffer[0] & 0x24) == 0x20) {
            // UID incomplete, PICC compliant with ISO/IEC 14443-4
            memcpy(uid_cln, id, 4);
            id_size += 4;
            return id_size;
        } else if ((buffer[0] & 0x04)) {
            // UID incomplete, continue the cascade
            memcpy(uid_cln+1, id, 3);
            id += 3;
            id_size += 3;
        } else {
            return CARD_ERROR;
        }
    }

    return CARD_ERROR;
}

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

void iso14443aInit(void) {
    // TODO nothing to do yet
}

void iso14443aObjectInit(ISO14443AProtocol *pp) {
    pp->status = ISO14443A_STOPPED;
}

void iso14443aStart(ISO14443AProtocol *pp, ISO14443AProtocolConfig *config) {
    pp->pcdp = config->pcd_driver;
    pcdStart(pp->pcdp, config->pcd_config);
    pp->status = ISO14443A_READY;
}

bool iso14443aRequest(ISO14443AProtocol *pp, uint8_t req_mode, uint8_t tag_type) {
    (void)req_mode;
    (void)tag_type;
    uint8_t buffer[3];
    buffer[0] = REQA;
    uint8_t size = 1;
    PCDStatus status = pcdSynchronousTransceive(pp->pcdp, buffer, buffer, &size, 0x07, 0x00);
    if (status == PCD_NO_PICC) return false;
    buffer[0] = REQA;
    pcdSynchronousTransceive(pp->pcdp, buffer, buffer, &size, 0x07, 0x00);
    return true;
}

void iso14443aAnticollision(ISO14443AProtocol *pp, uint8_t max_uids, PICC_UID *detected_uids,
                            uint8_t* uids_amount) {
    // TODO implement *REAL* anticollision
    (void)max_uids;
    uint8_t buffer[3];
    buffer[0] = REQA;
    uint8_t size = 1;
    PCDStatus status = pcdSynchronousTransceive(pp->pcdp, buffer, buffer, &size, 0x07, 0x00);
    if (status == PCD_NO_PICC) {
        *uids_amount = 0;
        return;
    }
    int8_t result = iso14443_perform_cascade(pp, detected_uids[0].bytes);
    if (result < 0) {
        *uids_amount = 0;
        return;
    }
    detected_uids[0].size = result;
    *uids_amount = 1;
}

bool iso14443aPICCSelect(ISO14443AProtocol *pp, uint8_t command, PICC_UID *uid){
    (void)pp;
    (void)command;
    (void)uid;
    return false;
}

bool iso14443aPICCAuthenticate(ISO14443AProtocol *pp, uint8_t command_code,
                               uint8_t block_address, uint8_t *sector_key,
                               uint8_t *serial_number) {
    (void)pp;
    (void)command_code;
    (void)block_address;
    (void)sector_key;
    (void)serial_number;
    return false;
}

bool iso14443aPICCRead(ISO14443AProtocol *pp, uint8_t block_address, uint8_t *buffer) {
    (void)pp;
    (void)block_address;
    (void)buffer;
    return false;
}

bool iso14443aPICCWrite(ISO14443AProtocol *pp, uint8_t block_address, uint8_t *buffer) {
    (void)pp;
    (void)block_address;
    (void)buffer;
    return false;
}

bool iso14443aPICCHalt(ISO14443AProtocol *pp) {
    (void)pp;
    return false;
}

#endif /* HAL_USE_ISO14443A_PROTOCOL */

/** @} */

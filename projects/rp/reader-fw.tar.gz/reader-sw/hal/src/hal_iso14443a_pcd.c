/**
 * @file    hal_iso14443a_pcd.c
 * @brief   ISO14443A PCD generic driver implementation
 *
 * @addtogroup ISO14443A_PCD
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if HAL_USE_ISO14443A_PCD || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/


/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

// TODO these should be more than proxies to the low-level drivers

void pcdInit(void) {
    ISO14443A_PCD_dsp_init();
}

void pcdObjectInit(PCDDriver* pcdp) {
    ISO14443A_PCD_driver_object_init(pcdp);
}

void pcdStart(PCDDriver* pcdp, PCDConfig* config) {
    ISO14443A_PCD_dsp_start(pcdp, config);
}

void pcdStop(PCDDriver* pcdp) {
    ISO14443A_PCD_dsp_stop(pcdp);
}

PCDStatus pcdAntennaOn(PCDDriver* pcdp) {
    return ISO14443A_PCD_dsp_antenna_on(pcdp);
}

PCDStatus pcdAntennaOff(PCDDriver* pcdp) {
    return ISO14443A_PCD_dsp_antenna_off(pcdp);
}

uint16_t pcdCalculateCRC(PCDDriver *pcdp, uint8_t *buffer, uint8_t length) {
    // TODO check whether we could do this locally
    return ISO14443A_PCD_calculate_crc(pcdp, buffer, length);
}

PCDStatus pcdPerformSelfTest(PCDDriver* pcdp) {
    return ISO14443A_PCD_dsp_perform_self_test(pcdp);
}

PCDStatus pcdSetCommunicationParameters(PCDDriver* pcdp, PCDCommunicationParameters *params) {
    return ISO14443A_PCD_dsp_set_comm_params(pcdp, params);
}

PCDStatus pcdSynchronousTransmit(PCDDriver* pcdp, uint8_t* buffer, uint8_t length,
                                 uint8_t last_bits) {
    return ISO14443A_PCD_dsp_sync_transmit(pcdp, buffer, length, last_bits);
}

PCDStatus pcdSynchronousReceive(PCDDriver* pcdp, uint8_t* buffer, uint8_t *length,
                                uint8_t bits_align) {
    return ISO14443A_PCD_dsp_sync_receive(pcdp, buffer, length, bits_align);
}

PCDStatus pcdSynchronousTransceive(PCDDriver* pcdp, uint8_t *tx_buffer, uint8_t *rx_buffer, uint8_t *length,
                                   uint8_t last_bits, uint8_t bits_align) {
    return ISO14443A_PCD_dsp_sync_transceive(pcdp, tx_buffer, rx_buffer, length, last_bits, bits_align);
}

uint8_t pcdGetReceiveCollisionPosition(PCDDriver* pcdp) {
    return ISO14443A_PCD_dsp_get_coll_position(pcdp);
}

PCDStatus pcdSynchronousMifareAutheht(PCDDriver* pcdp, uint8_t command_code,
                                      uint8_t block_address, uint8_t* sector_key,
                                      uint8_t* serial_number) {
    return ISO14443A_PCD_dsp_sync_mfauthent(pcdp, command_code, block_address, sector_key,
                                            serial_number);
}


#endif /* HAL_USE_ISO14443A_PCD */

/** @} */

/**
 * @file    hal_custom.c
 * @brief   Custom HAL subsystem code.
 *
 * @addtogroup HAL_CUSTOM
 * @{
 */

#include "hal.h"
#include "hal_custom.h"

#if (HAL_USE_CUSTOM == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   HAL initialization (custom part).
 *
 * @init
 */
void halCustomInit(void) {

#if (HAL_USE_ISO14443A_PCD == TRUE) || defined(__DOXYGEN__)
  pcdInit();
#endif

#if (HAL_USE_ISO14443A_PROTOCOL == TRUE) || defined(__DOXYGEN__)
  iso14443aInit();
#endif
}

#endif /* HAL_USE_CUSTOM */

/** @} */

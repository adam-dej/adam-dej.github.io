# reader-hw
Schematic and PCB layout for the Reader

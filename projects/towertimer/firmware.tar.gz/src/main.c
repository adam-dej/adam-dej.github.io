#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <avr/sleep.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "interfaces.h"
#include "bin.h"

#include "lib-ds3234/ds3234.h"
#include "embegfx/display_device.h"
#include "embegfx/devices/pcf8531.h"
#include "embegfx/devices/virtual_mirror.h"
#include "embegfx/drawing/1bit.h"

#define LED_ERR_PORT PORTB
#define LED_ERR_DDR DDRB
#define LED_ERR_NUM 1

#define LED_OK_PORT PORTC
#define LED_OK_DDR DDRC
#define LED_OK_NUM 3

#define RELAY_1_PORT PORTB
#define RELAY_1_DDR DDRB
#define RELAY_1_NUM 6

#define RELAY_2_PORT PORTD
#define RELAY_2_DDR DDRD
#define RELAY_2_NUM 4

#define RELAY_3_PORT PORTB
#define RELAY_3_DDR DDRB
#define RELAY_3_NUM 7

DISPLAY_1BIT *display;

uint8_t read_byte(void *address) {
	return pgm_read_byte(address);
}

void gpio_init() {
	LED_ERR_DDR |= (1 << LED_ERR_NUM);
	LED_OK_DDR |= (1 << LED_OK_NUM);
	RELAY_1_DDR |= (1 << RELAY_1_NUM);
	RELAY_2_DDR |= (1 << RELAY_2_NUM);
	RELAY_3_DDR |= (1 << RELAY_3_NUM);
}

void panic(uint8_t reason) {
	cli();
	LED_ERR_PORT |= (1 << LED_ERR_NUM);

	RELAY_1_PORT &= ~(1 << RELAY_1_NUM);
	RELAY_2_PORT &= ~(1 << RELAY_2_NUM);
	RELAY_3_PORT &= ~(1 << RELAY_3_NUM);

	display->clear_display(display->data);
	draw_text_1bit(0, 0, "PANIC!", font_6px, read_byte, display);
	draw_text_1bit(0, 7, "Critical system error", font_6px, read_byte, display);
	char code[] = {'C', 'o', 'd', 'e', ' ', '0' + (reason/100), '0' + ((reason%100) / 10), '0' + (reason % 10)};
	draw_text_1bit(0, 14, code, font_6px, read_byte, display);
	display->commit(display->data);

	uint8_t bit = 0;

	while(true) {
		LED_OK_PORT |= (1 << LED_OK_NUM);
		if (reason & (1 << bit)) _delay_ms(400);
		else _delay_ms(800);
		LED_OK_PORT &= ~(1 << LED_OK_NUM);
		_delay_ms(800);
		bit++;
		if (bit == 8) {
			_delay_ms(2000);
			bit = 0;
		}
	}
}

int main(void) {

	//Setup stdout to custom usart stream
	stdout = &usart_out;
	gpio_init();
	usart_init();
	i2c_init();
	display_init();
	ds3234_init(spi_init, spi_transfer, ds3234_spi_slave_select, ds3234_spi_slave_unselect);
	display = mirror_device(pcf8531_make_device(twi_start, i2c_send_address, i2c_write, twi_stop), VIRTUAL_MIRROR_X | VIRTUAL_MIRROR_Y, 128, 32);

	

	while(1);

	return 0;
}
embegfx
=======

Minimalistic, modular and easily extensible graphics library for embedded systems

#define UBRR (F_CPU/16/BAUD-1)

#define MT_SLA_ACK 0x18
#define MT_DATA_ACK 0x28
#define START_OK 0x08

#define BAUD 38400

#define DD_MOSI 3
#define DD_MISO 4
#define DD_SCK 5
#define DD_SS 2
#define DDR_SPI DDRB

#define DDR_DS3234_SS DDRB
#define PORT_DS3234_SS PORTB
#define DS_3234_SS 2

void usart_init() {

    // Set baud rate
    UBRRH = (uint8_t)(UBRR>>8);
    UBRRL = (uint8_t)UBRR;

    // Enable receiver and transmitter
    UCSRB = (1<<RXEN)|(1<<TXEN);

    // Set frame format: 8data, 1stop bit
    UCSRC = (1<<URSEL)|(3<<UCSZ0);
}

int __usart_putchar(char data, FILE *stream) {

    // Wait for empty transmit buffer
    while ( !(UCSRA & (_BV(UDRE))) );

    // Start transmission
    UDR = data;

    while ( !(UCSRA & (_BV(UDRE))) );
    // Wait for transmission completion

    return 0;
}

bool twi_start() {
    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));

    if ((TWSR & 0xF8) != START_OK) {
        printf("ERROR! (%02x)\n", (TWSR & 0x8F));
        return false;
    }
    return true;
}

void twi_stop() {
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}

bool i2c_send_address() {
    TWDR = 0b01111000;
    TWCR = (1<<TWINT) | (1<<TWEN);
    while(!(TWCR & (1<<TWINT)));

    if ((TWSR & 0xF8) != MT_SLA_ACK) {
        printf("NAK! (%02x)\n", (TWSR & 0x8F));
        return false;
    }
    return true;
}

bool i2c_write(uint8_t byte) {
    TWDR = byte;
    TWCR = (1<<TWINT) | (1<<TWEN);
    while(!(TWCR & (1<<TWINT)));

    if ((TWSR & 0xF8) != MT_DATA_ACK) {
        printf("%02x NAK! (%02x)\n", byte, (TWSR & 0x8F));
        return false;
    }
    return true;
}

void i2c_init() {
    TWSR = 0x00; //No prescalers
    TWBR = 0x02; //400kHz @ 8MHz
    TWCR = (1 <<  TWEN); //Enable TWI
}


void spi_init() {
    DDR_SPI |= (1<<DD_MOSI) | (1<<DD_SCK) | (1<<DD_SS);
    DDR_SPI &= ~(1<<DD_MISO);

    DDR_DS3234_SS |= (1<<DS_3234_SS);

    SPCR = (1<<MSTR) | (1<<CPOL) | (1<<CPHA);
    SPCR |= (1<<SPE);

    PORT_DS3234_SS &= ~(1<<DS_3234_SS);
    PORT_DS3234_SS |= (1<<DS_3234_SS);
}

uint8_t spi_transfer(uint8_t data) {
    SPDR = data;
    while(!(SPSR & (1 <<SPIF)));
    return SPDR;
}

void ds3234_spi_slave_select() {
    PORT_DS3234_SS &= ~(1<<DS_3234_SS);
}

void ds3234_spi_slave_unselect() {
    PORT_DS3234_SS |= (1<<DS_3234_SS);
}

void display_init() {
    twi_start();
    i2c_send_address();

    i2c_write(0b00000000);

    i2c_write(0x01);
    i2c_write(0b00100000);
    i2c_write(0b00001001);
    i2c_write(0b00001100);
    i2c_write(0b00000101);
    i2c_write(0b00010111);

    twi_stop();
}


//Setup custom streams for stdio
FILE usart_out = FDEV_SETUP_STREAM(__usart_putchar, NULL, _FDEV_SETUP_WRITE);

